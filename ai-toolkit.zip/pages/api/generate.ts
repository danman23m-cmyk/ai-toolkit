
export default function handler(req, res) {
  res.status(200).json({ message: "API not used in no-AI version" });
}
