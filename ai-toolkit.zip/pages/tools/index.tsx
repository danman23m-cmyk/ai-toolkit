
export default function Tools() {
  return (
    <div style={{ padding: 20 }}>
      <h1>Tools Page</h1>
      <a href="/">Go Home</a>
    </div>
  );
}
